//include.js
$(document).ready(function(){
    // include
    $('#header').load("header.html");
    $('#footer').load("footer.html");

});